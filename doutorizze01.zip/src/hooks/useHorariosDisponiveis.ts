import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { format, addMinutes, parseISO, isBefore, isAfter, startOfDay } from 'date-fns';
import { toast } from 'sonner';
import { getMockHorariosFuncionamento, mockHorariosFuncionamento } from '@/data/mock-horarios';

export interface HorarioFuncionamento {
  id: string;
  clinica_id: string;
  dia_semana: number; // 0 = domingo, 1 = segunda, etc.
  hora_inicio: string;
  hora_fim: string;
  duracao_consulta: number;
}

export interface HorarioBloqueado {
  id: string;
  clinica_id: string;
  profissional_id?: string;
  data_inicio: string;
  data_fim: string;
  hora_inicio?: string;
  hora_fim?: string;
  motivo?: string;
  ativo: boolean;
}

export interface SlotHorario {
  horario: string;
  disponivel: boolean;
  motivo?: string; // Motivo da indisponibilidade
}

export const useHorariosDisponiveis = (clinicaId: string) => {
  
  const [horariosFuncionamento, setHorariosFuncionamento] = useState<HorarioFuncionamento[]>([]);
  const [horariosBloqueados, setHorariosBloqueados] = useState<HorarioBloqueado[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Carregar horários de funcionamento
  const carregarHorariosFuncionamento = useCallback(async () => {
    console.log('[useHorariosDisponiveis] carregarHorariosFuncionamento chamado com clinicaId:', clinicaId);
    
    if (!clinicaId) {
      console.warn('[useHorariosDisponiveis] clinicaId não fornecido para carregarHorariosFuncionamento');
      return;
    }

    try {
      setLoading(true);
      console.log('[useHorariosDisponiveis] Fazendo consulta ao Supabase para clinica_id:', clinicaId);
      console.log('🔍 [DEBUG] Buscando horários de funcionamento para clínica:', clinicaId);
      console.log('🔍 [DEBUG] Executando query no Supabase...');
      
      const { data, error } = await supabase
        .from('horarios_funcionamento')
        .select('*')
        .eq('clinica_id', clinicaId)
        .order('dia_semana');

      console.log('[useHorariosDisponiveis] Resposta do Supabase:', { data, error });
      console.log('🔍 [DEBUG] Query executada. Error:', error);
      console.log('🔍 [DEBUG] Query executada. Data:', data);

      if (error) {
        console.error('[useHorariosDisponiveis] Erro ao carregar horários de funcionamento:', error);
        // Fallback para dados mock em caso de erro
        const mockDataRaw = getMockHorariosFuncionamento(clinicaId);
        
        const mockData = mockDataRaw.map(mock => ({
          id: mock.id,
          clinica_id: mock.clinic_id,
          dia_semana: mock.dia_semana,
          hora_inicio: mock.hora_inicio,
          hora_fim: mock.hora_fim,
          duracao_consulta: 30 // Duração padrão
        }));
        
        setHorariosFuncionamento(mockData);
        return;
      }

      if (data && data.length > 0) {
        console.log('[useHorariosDisponiveis] Horários encontrados:', data.length);
        setHorariosFuncionamento(data);
      } else {
        console.warn('[useHorariosDisponiveis] Nenhum horário de funcionamento encontrado para a clínica:', clinicaId);
        // Usar dados mock se não houver dados reais
        const mockDataRaw = getMockHorariosFuncionamento(clinicaId);
        
        const mockData = mockDataRaw.map(mock => ({
          id: mock.id,
          clinica_id: mock.clinic_id,
          dia_semana: mock.dia_semana,
          hora_inicio: mock.hora_inicio,
          hora_fim: mock.hora_fim,
          duracao_consulta: 30 // Duração padrão
        }));
        
        setHorariosFuncionamento(mockData);
      }
    } catch (error) {
      console.error('[useHorariosDisponiveis] Erro ao carregar horários:', error);
      const mockDataRaw = getMockHorariosFuncionamento(clinicaId);
      
      const mockData = mockDataRaw.map(mock => ({
        id: mock.id,
        clinica_id: mock.clinic_id,
        dia_semana: mock.dia_semana,
        hora_inicio: mock.hora_inicio,
        hora_fim: mock.hora_fim,
        duracao_consulta: 30 // Duração padrão
      }));
      
      setHorariosFuncionamento(mockData);
    } finally {
      setLoading(false);
    }
  }, [clinicaId]);

  // Carregar horários bloqueados
  const carregarHorariosBloqueados = useCallback(async (dataInicio?: string, dataFim?: string) => {
    if (!clinicaId) return;
    
    try {
      let query = supabase
        .from('horarios_bloqueados')
        .select('*')
        .eq('clinica_id', clinicaId);

      if (dataInicio) {
        query = query.gte('data_fim', dataInicio);
      }
      
      if (dataFim) {
        query = query.lte('data_inicio', dataFim);
      }

      const { data, error } = await query;
      if (error) throw error;
      
      setHorariosBloqueados(data || []);
    } catch (err) {
      console.error('Erro ao carregar horários bloqueados:', err);
      setError('Erro ao carregar horários bloqueados');
    }
  }, [clinicaId]);

  // Obter horários disponíveis para uma data específica
  const obterHorariosDisponiveis = useCallback(async (
    data: string,
    profissionalId?: string,
    duracaoMinutos: number = 30
  ): Promise<SlotHorario[]> => {
    console.log('🚀 [HORARIOS] =================================');
    console.log('🚀 [HORARIOS] obterHorariosDisponiveis INICIADO');
    console.log('🚀 [HORARIOS] Data solicitada:', data);
    console.log('🚀 [HORARIOS] ClinicaId:', clinicaId);
    console.log('🚀 [HORARIOS] ProfissionalId:', profissionalId);
    console.log('🚀 [HORARIOS] DuracaoMinutos:', duracaoMinutos);
    console.log('🚀 [HORARIOS] Estado horariosFuncionamento:', horariosFuncionamento.length, 'itens');
    console.log('🚀 [HORARIOS] =================================');
    
    if (!clinicaId) {
      console.log('🚫 Sem clinicaId, retornando array vazio');
      return [];
    }
    
    // Aguardar carregamento dos horários de funcionamento se necessário
    if (horariosFuncionamento.length === 0) {
      console.warn('⏳ [DEBUG] Horários de funcionamento não carregados, aguardando...');
      await carregarHorariosFuncionamento();
      
      // Aguardar um pouco para o estado ser atualizado
      await new Promise(resolve => setTimeout(resolve, 100));
      console.warn('⏳ [DEBUG] Após aguardar, horários carregados:', horariosFuncionamento.length);
      
      // Se ainda não temos horários após carregar, tentar novamente
      if (horariosFuncionamento.length === 0) {
        console.log('⚠️ Ainda sem horários após carregamento, tentando buscar diretamente...');
        try {
          const { data: horariosData, error } = await supabase
            .from('horarios_funcionamento')
            .select('*')
            .eq('clinica_id', clinicaId)
            .order('dia_semana');
            
          if (error) throw error;
          
          if (horariosData && horariosData.length > 0) {
            console.log('✅ Horários carregados diretamente:', horariosData.length);
            // Usar os horários carregados diretamente para esta operação
            const horariosTemp = horariosData;
            
            const dataObj = parseISO(data);
            const diaSemana = dataObj.getDay();
            const hoje = startOfDay(new Date());
            const dataConsulta = startOfDay(dataObj);
            
            console.log('📅 Data processada - diaSemana:', diaSemana, 'dataObj:', dataObj);
            
            // Verificar se a data não é no passado
            if (isBefore(dataConsulta, hoje)) {
              console.log('⏰ Data é no passado, retornando array vazio');
              return [];
            }

            // Buscar horário de funcionamento para o dia da semana
            const funcionamento = horariosTemp.find(h => h.dia_semana === diaSemana);
            
            console.log('🏢 Funcionamento encontrado para dia', diaSemana, ':', funcionamento);
            
            if (!funcionamento) {
              console.log('❌ Nenhum funcionamento encontrado para dia da semana:', diaSemana);
              return [];
            }
            
            return await gerarSlotsHorario(funcionamento, data, profissionalId, duracaoMinutos);
          } else {
            console.log('❌ Nenhum horário de funcionamento encontrado no banco');
            return [];
          }
        } catch (err) {
          console.error('❌ Erro ao carregar horários diretamente:', err);
          return [];
        }
      }
    }
    
    try {
      const dataObj = parseISO(data);
      const diaSemana = dataObj.getDay();
      const hoje = startOfDay(new Date());
      const dataConsulta = startOfDay(dataObj);
      
      console.log('📅 Data processada - diaSemana:', diaSemana, 'dataObj:', dataObj);
      console.log('📊 Horários funcionamento disponíveis:', horariosFuncionamento.length);
      
      // Verificar se a data não é no passado
      if (isBefore(dataConsulta, hoje)) {
        console.log('⏰ Data é no passado, retornando array vazio');
        return [];
      }

      // Buscar horário de funcionamento para o dia da semana
      const funcionamento = horariosFuncionamento.find(h => h.dia_semana === diaSemana);
      
      console.log('🏢 Funcionamento encontrado para dia', diaSemana, ':', funcionamento);
      
      if (!funcionamento) {
        console.log('❌ Nenhum funcionamento encontrado para dia da semana:', diaSemana);
        return [];
      }
      
      return await gerarSlotsHorario(funcionamento, data, profissionalId, duracaoMinutos);
    } catch (err) {
      console.error('❌ Erro ao obter horários disponíveis:', err);
      toast.error('Erro ao carregar horários disponíveis');
      return [];
    }
  }, [clinicaId, horariosFuncionamento, horariosBloqueados, carregarHorariosFuncionamento]);

  // Função auxiliar para gerar slots de horário
   const gerarSlotsHorario = useCallback(async (
     funcionamento: HorarioFuncionamento,
     data: string,
     profissionalId?: string,
     duracaoMinutos: number = 30
   ): Promise<SlotHorario[]> => {
     try {
       const dataObj = parseISO(data);
 
       // Buscar agendamentos existentes para a data
       let queryAgendamentos = supabase
         .from('agendamentos')
         .select('data_hora')
         .eq('clinica_id', clinicaId)
         .gte('data_hora', `${data}T00:00:00`)
         .lt('data_hora', `${data}T23:59:59`)
         .in('status', ['pendente', 'confirmado']);

       if (profissionalId) {
         queryAgendamentos = queryAgendamentos.eq('profissional_id', profissionalId);
       }

       const { data: agendamentos, error: agendamentoError } = await queryAgendamentos;
       if (agendamentoError) throw agendamentoError;

       const horariosOcupados = new Set(agendamentos?.map(a => {
         const dataHora = new Date(a.data_hora);
         return format(dataHora, 'HH:mm');
       }) || []);

       // Verificar bloqueios para a data
       const bloqueiosData = horariosBloqueados.filter(bloqueio => {
         const dentroIntervalo = data >= bloqueio.data_inicio && data <= bloqueio.data_fim;
         const profissionalMatch = !profissionalId || !bloqueio.profissional_id || bloqueio.profissional_id === profissionalId;
         return dentroIntervalo && profissionalMatch;
       });

       // Gerar slots de horário
       const slots: SlotHorario[] = [];
       const [horaInicio, minutoInicio] = funcionamento.hora_inicio.split(':').map(Number);
       const [horaFim, minutoFim] = funcionamento.hora_fim.split(':').map(Number);
       
       console.log('⏰ Gerando slots de', funcionamento.hora_inicio, 'até', funcionamento.hora_fim);
       
       let horarioAtual = new Date(dataObj);
       horarioAtual.setHours(horaInicio, minutoInicio, 0, 0);
       
       const horarioLimite = new Date(dataObj);
       horarioLimite.setHours(horaFim, minutoFim, 0, 0);

       while (isBefore(horarioAtual, horarioLimite)) {
         const horarioStr = format(horarioAtual, 'HH:mm');
         let disponivel = true;
         let motivo = '';

         // Verificar se está ocupado
         if (horariosOcupados.has(horarioStr)) {
           disponivel = false;
           motivo = 'Horário já agendado';
         }

         // Verificar bloqueios
         if (disponivel) {
           const bloqueio = bloqueiosData.find(b => {
             if (!b.hora_inicio || !b.hora_fim) {
               return true; // Bloqueio do dia inteiro
             }
             return horarioStr >= b.hora_inicio && horarioStr < b.hora_fim;
           });

           if (bloqueio) {
             disponivel = false;
             motivo = bloqueio.motivo || 'Horário bloqueado';
           }
         }

         // Verificar se é no passado (para hoje)
         if (disponivel && format(dataObj, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')) {
           const agora = new Date();
           if (isBefore(horarioAtual, agora)) {
             disponivel = false;
             motivo = 'Horário já passou';
           }
         }

         slots.push({
           horario: horarioStr,
           disponivel,
           motivo: disponivel ? undefined : motivo
         });

         horarioAtual = addMinutes(horarioAtual, duracaoMinutos);
       }

       console.log('✅ Slots gerados:', slots.length, 'total, disponíveis:', slots.filter(s => s.disponivel).length);
       return slots;
     } catch (err) {
       console.error('❌ Erro ao gerar slots de horário:', err);
       return [];
     }
   }, [clinicaId, horariosBloqueados]);

  // Criar horário de funcionamento
  const criarHorarioFuncionamento = useCallback(async (horario: Omit<HorarioFuncionamento, 'id'>) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('horarios_funcionamento')
        .insert([horario])
        .select()
        .single();

      if (error) throw error;
      
      setHorariosFuncionamento(prev => [...prev, data]);
      toast.success('Horário de funcionamento criado com sucesso!');
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro ao criar horário de funcionamento';
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // Atualizar horário de funcionamento
  const atualizarHorarioFuncionamento = useCallback(async (id: string, updates: Partial<HorarioFuncionamento>) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('horarios_funcionamento')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      setHorariosFuncionamento(prev => 
        prev.map(item => item.id === id ? data : item)
      );
      
      toast.success('Horário de funcionamento atualizado com sucesso!');
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro ao atualizar horário de funcionamento';
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // Remover horário de funcionamento
  const removerHorarioFuncionamento = useCallback(async (id: string) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('horarios_funcionamento')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setHorariosFuncionamento(prev => 
        prev.filter(item => item.id !== id)
      );
      
      toast.success('Horário de funcionamento removido com sucesso!');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro ao remover horário de funcionamento';
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // Criar bloqueio de horário
  const criarBloqueioHorario = useCallback(async (bloqueio: Omit<HorarioBloqueado, 'id'>) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('horarios_bloqueados')
        .insert([bloqueio])
        .select()
        .single();

      if (error) throw error;
      
      setHorariosBloqueados(prev => [...prev, data]);
      toast.success('Bloqueio de horário criado com sucesso!');
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro ao criar bloqueio de horário';
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // Remover bloqueio de horário
  const removerBloqueioHorario = useCallback(async (id: string) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('horarios_bloqueados')
        .update({ ativo: false })
        .eq('id', id);

      if (error) throw error;
      
      setHorariosBloqueados(prev => 
        prev.filter(item => item.id !== id)
      );
      
      toast.success('Bloqueio de horário removido com sucesso!');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro ao remover bloqueio de horário';
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // Verificar se uma data tem horários disponíveis
  const temHorariosDisponiveis = useCallback(async (data: string, profissionalId?: string): Promise<boolean> => {
    const slots = await obterHorariosDisponiveis(data, profissionalId);
    return slots.some(slot => slot.disponivel);
  }, [obterHorariosDisponiveis]);

  // Carregar dados na inicialização
  useEffect(() => {

    if (clinicaId) {
      console.log('📋 Carregando horários de funcionamento e bloqueados...');
      carregarHorariosFuncionamento();
      carregarHorariosBloqueados();
    }
  }, [clinicaId, carregarHorariosFuncionamento, carregarHorariosBloqueados]);

  // Log para monitorar mudanças no estado horariosFuncionamento
  useEffect(() => {
    console.log('📊 ESTADO HORÁRIOS FUNCIONAMENTO ATUALIZADO:', horariosFuncionamento);
    console.log('📊 Quantidade de horários:', horariosFuncionamento.length);
    if (horariosFuncionamento.length > 0) {
      console.log('📊 Primeiro horário:', horariosFuncionamento[0]);
    }
  }, [horariosFuncionamento]);

  return {
    horariosFuncionamento,
    horariosBloqueados,
    loading,
    error,
    obterHorariosDisponiveis,
    criarHorarioFuncionamento,
    atualizarHorarioFuncionamento,
    removerHorarioFuncionamento,
    criarBloqueioHorario,
    removerBloqueioHorario,
    temHorariosDisponiveis,
    carregarHorariosFuncionamento,
    carregarHorariosBloqueados
  };
};