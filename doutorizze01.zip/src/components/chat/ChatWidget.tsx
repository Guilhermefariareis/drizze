import React from "react";

export const ChatWidget: React.FC<{ className?: string }> = () => {
  return null;
};