import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, FileText, Save, X, Loader2, User, Phone, Mail } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useHorariosDisponiveis } from '@/hooks/useHorariosDisponiveis';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

interface Servico {
  id: string;
  nome: string;
  duracao_minutos: number;
  preco: number;
}

interface AgendamentoData {
  id?: string;
  servico_id: string;
  paciente_id?: string;
  clinica_id: string;
  profissional_id?: string;
  data_hora: string;
  horario: string;
  status?: 'pendente' | 'confirmado' | 'cancelado' | 'concluido';
  observacoes?: string;
  valor?: number;
  tipo_agendamento?: 'interno' | 'paciente';
  nome_paciente?: string;
  telefone_paciente?: string;
  email_paciente?: string;
}

interface FormularioAgendamentoProps {
  clinicaId: string;
  agendamento?: AgendamentoData;
  onSalvar: (agendamento: AgendamentoData) => Promise<void>;
  onCancelar: () => void;
  modo?: 'criar' | 'editar';
  hideTypeSelection?: boolean;
}

const FormularioAgendamento: React.FC<FormularioAgendamentoProps> = ({
  clinicaId,
  agendamento,
  onSalvar,
  onCancelar,
  modo = 'criar',
  hideTypeSelection = false
}) => {
  const { user } = useAuth();
  
  const [formData, setFormData] = useState<AgendamentoData>({
    servico_id: '',
    clinica_id: clinicaId || '',
    profissional_id: '',
    data_hora: '',
    horario: '',
    observacoes: '',
    valor: 0,
    tipo_agendamento: 'paciente',
    nome_paciente: '',
    telefone_paciente: '',
    email_paciente: '',
    ...agendamento
  });

  console.log('🔍 [DEBUG] FormularioAgendamento - clinicaId recebido:', clinicaId);
  console.log('🔍 [DEBUG] FormularioAgendamento - clinicaId é vazio?', !clinicaId || clinicaId === '');
  console.log('🔍 [DEBUG] FormularioAgendamento - formData.clinica_id:', formData.clinica_id);
  
  // Atualizar clinica_id no formData quando clinicaId prop mudar
  useEffect(() => {
    if (clinicaId && clinicaId !== formData.clinica_id) {
      console.log('🔄 [DEBUG] FormularioAgendamento - Atualizando clinica_id no formData:', clinicaId);
      setFormData(prev => ({ ...prev, clinica_id: clinicaId }));
    }
  }, [clinicaId, formData.clinica_id]);

  // Atualizar formData quando prop agendamento muda (para modo de edição)
  useEffect(() => {
    if (agendamento && modo === 'editar') {
      console.log('🔄 [DEBUG] FormularioAgendamento - Carregando dados para edição:', agendamento);
      
      // Extrair horário da data_hora se existir
      let horario = '';
      if (agendamento.data_hora) {
        const dataHora = new Date(agendamento.data_hora);
        horario = dataHora.toTimeString().slice(0, 5); // HH:MM
      }
      
      setFormData({
        ...agendamento,
        clinica_id: clinicaId || agendamento.clinica_id || '',
        horario: horario,
        servico_id: agendamento.servico_id || '',
        data_hora: agendamento.data_hora || '',
        observacoes: agendamento.observacoes || '',
        valor: agendamento.valor || 0,
        tipo_agendamento: agendamento.tipo_agendamento || 'paciente',
        nome_paciente: agendamento.nome_paciente || '',
        telefone_paciente: agendamento.telefone_paciente || '',
        email_paciente: agendamento.email_paciente || ''
      });
    }
  }, [agendamento, modo, clinicaId]);

  const [servicos, setServicos] = useState<Servico[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});

  console.log('🔍 [FormularioAgendamento] clinicaId recebido:', clinicaId);
  console.log('🔍 [FormularioAgendamento] clinicaId usado no hook:', clinicaId);
  
  const { obterHorariosDisponiveis } = useHorariosDisponiveis(clinicaId);
  const [horariosDisponiveis, setHorariosDisponiveis] = useState<Array<{ horario: string; disponivel: boolean }>>([]);

  // Carregar dados iniciais
  useEffect(() => {
    const carregarDados = async () => {
      try {
        const { data: servicosData, error: servicosError } = await supabase
          .from('servicos')
          .select('id, nome, duracao_minutos, preco')
          .eq('clinic_id', clinicaId)
          .eq('ativo', true)
          .order('nome');

        if (servicosError) throw servicosError;
        setServicos(servicosData || []);
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
        toast.error('Erro ao carregar dados do formulário');
      } finally {
        setLoadingData(false);
      }
    };

    carregarDados();
  }, [clinicaId]);

  // Efeito para carregar horários quando data ou serviço mudam
  useEffect(() => {
    const carregarHorarios = async () => {
      // Para agendamento interno (hideTypeSelection=true), só precisa da data
      // Para agendamento de cliente, precisa da data E do serviço
      const temData = formData.data_hora && formData.data_hora.trim() !== '';
      const temServico = formData.servico_id && formData.servico_id.trim() !== '';
      
      const deveCarregar = hideTypeSelection 
        ? temData 
        : temData && temServico;
      

      
      if (deveCarregar) {
        try {
          const dataFormatada = formData.data_hora.split('T')[0];
          
          // Validar se a data é válida
          if (dataFormatada && dataFormatada.length === 10) {
            const horarios = await obterHorariosDisponiveis(
              dataFormatada,
              formData.profissional_id
            );
            setHorariosDisponiveis(horarios);
          } else {
            setHorariosDisponiveis([]);
          }
        } catch (error) {
          console.error('❌ Erro ao carregar horários:', error);
          setHorariosDisponiveis([]);
        }
      } else {
          setHorariosDisponiveis([]);
        }
    };

    carregarHorarios();
  }, [formData.data_hora, formData.servico_id, obterHorariosDisponiveis, hideTypeSelection]);



  const handleInputChange = (field: keyof AgendamentoData, value: any) => {
    if (field === 'horario' && value && formData.data_hora) {
      const dataAtual = formData.data_hora.split('T')[0];
      const novaDataHora = `${dataAtual}T${value}:00`;
      setFormData(prev => ({ ...prev, [field]: value, data_hora: novaDataHora }));
    } else {
      setFormData(prev => ({ ...prev, [field]: value }));
    }
    
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validarFormulario = (): boolean => {
    const novosErros: Record<string, string> = {};

    if (!hideTypeSelection && !formData.servico_id) {
      novosErros.servico_id = 'Selecione um serviço';
    }

    if (!formData.data_hora) {
      novosErros.data_hora = 'Selecione uma data';
    }

    if (!formData.horario) {
      novosErros.horario = 'Selecione um horário';
    }



    if (formData.tipo_agendamento === 'paciente') {
      if (!formData.nome_paciente?.trim()) {
        novosErros.nome_paciente = 'Nome do paciente é obrigatório';
      }

      if (!formData.telefone_paciente?.trim()) {
        novosErros.telefone_paciente = 'Telefone é obrigatório';
      } else {
        const telefoneRegex = /^[\d\s\(\)\-\+]+$/;
        if (!telefoneRegex.test(formData.telefone_paciente)) {
          novosErros.telefone_paciente = 'Formato de telefone inválido';
        }
      }

      if (formData.email_paciente?.trim()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email_paciente)) {
          novosErros.email_paciente = 'Formato de email inválido';
        }
      }
    }

    setErrors(novosErros);
    return Object.keys(novosErros).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!clinicaId || clinicaId === '') {
      console.error('❌ [DEBUG] FormularioAgendamento - ERRO CRÍTICO: clinicaId não foi carregado ainda!');
      toast.error('Aguarde o carregamento dos dados da clínica');
      return;
    }
    
    if (!validarFormulario()) {
      toast.error('Por favor, corrija os erros no formulário');
      return;
    }

    setLoading(true);
    
    try {
      await onSalvar(formData);
      toast.success(modo === 'editar' ? 'Agendamento atualizado com sucesso!' : 'Agendamento criado com sucesso!');
      onCancelar();
    } catch (error) {
      console.error('Erro ao salvar agendamento:', error);
      toast.error('Erro ao salvar agendamento');
    } finally {
      setLoading(false);
    }
  };

  if (loadingData) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Carregando dados...</span>
      </div>
    );
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          {modo === 'editar' ? 'Editar Agendamento' : 'Novo Agendamento'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {!hideTypeSelection && (
            <div className="space-y-2">
              <Label htmlFor="servico_id">Serviço *</Label>
              <Select
                value={formData.servico_id}
                onValueChange={(value) => handleInputChange('servico_id', value)}
              >
                <SelectTrigger className={errors.servico_id ? 'border-red-500' : ''}>
                  <SelectValue placeholder="Selecione um serviço" />
                </SelectTrigger>
                <SelectContent>
                  {servicos.map((servico) => (
                    <SelectItem key={servico.id} value={servico.id}>
                      {servico.nome} - R$ {servico.preco.toFixed(2)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.servico_id && (
                <p className="text-sm text-red-500">{errors.servico_id}</p>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="data_hora">Data *</Label>
              <Input
                id="data_hora"
                type="date"
                value={formData.data_hora ? formData.data_hora.split('T')[0] : ''}
                onChange={(e) => {
                  const novaData = e.target.value;
                  if (novaData) {
                    const dataHora = formData.horario 
                      ? `${novaData}T${formData.horario}:00`
                      : `${novaData}T00:00:00`;
                    handleInputChange('data_hora', dataHora);
                  } else {
                    handleInputChange('data_hora', '');
                  }
                }}
                className={errors.data_hora ? 'border-red-500' : ''}
              />
              {errors.data_hora && (
                <p className="text-sm text-red-500">{errors.data_hora}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="horario">Horário *</Label>
              <Select
                value={formData.horario}
                onValueChange={(value) => handleInputChange('horario', value)}
              >
                <SelectTrigger className={errors.horario ? 'border-red-500' : ''}>
                  <SelectValue placeholder="Selecione um horário" />
                </SelectTrigger>
                <SelectContent>
                  {horariosDisponiveis.map((item) => (
                    <SelectItem 
                      key={item.horario} 
                      value={item.horario}
                      disabled={!item.disponivel}
                    >
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        {item.horario}
                        {!item.disponivel && (
                          <Badge variant="secondary" className="text-xs">
                            Ocupado
                          </Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.horario && (
                <p className="text-sm text-red-500">{errors.horario}</p>
              )}
            </div>
          </div>

          {formData.tipo_agendamento === 'paciente' && (
            <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
              <h3 className="font-medium text-blue-900 flex items-center gap-2">
                <User className="h-4 w-4" />
                Dados do Paciente
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome_paciente">Nome *</Label>
                  <Input
                    id="nome_paciente"
                    value={formData.nome_paciente || ''}
                    onChange={(e) => handleInputChange('nome_paciente', e.target.value)}
                    placeholder="Nome completo do paciente"
                    className={errors.nome_paciente ? 'border-red-500' : ''}
                  />
                  {errors.nome_paciente && (
                    <p className="text-sm text-red-500">{errors.nome_paciente}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="telefone_paciente">Telefone *</Label>
                  <Input
                    id="telefone_paciente"
                    value={formData.telefone_paciente || ''}
                    onChange={(e) => handleInputChange('telefone_paciente', e.target.value)}
                    placeholder="(11) 99999-9999"
                    className={errors.telefone_paciente ? 'border-red-500' : ''}
                  />
                  {errors.telefone_paciente && (
                    <p className="text-sm text-red-500">{errors.telefone_paciente}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email_paciente">Email</Label>
                <Input
                  id="email_paciente"
                  type="email"
                  value={formData.email_paciente || ''}
                  onChange={(e) => handleInputChange('email_paciente', e.target.value)}
                  placeholder="email@exemplo.com"
                  className={errors.email_paciente ? 'border-red-500' : ''}
                />
                {errors.email_paciente && (
                  <p className="text-sm text-red-500">{errors.email_paciente}</p>
                )}
              </div>
            </div>
          )}



          <div className="space-y-2">
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes || ''}
              onChange={(e) => handleInputChange('observacoes', e.target.value)}
              placeholder="Observações adicionais..."
              rows={3}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Confirmando...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  {modo === 'editar' ? 'Atualizar Agendamento' : 'Confirmar Agendamento'}
                </>
              )}
            </Button>
            <Button type="button" variant="outline" onClick={onCancelar}>
              <X className="mr-2 h-4 w-4" />
              Cancelar
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default FormularioAgendamento;