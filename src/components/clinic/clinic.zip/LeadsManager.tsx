import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Users, 
  Phone, 
  Mail, 
  Calendar, 
  TrendingUp,
  UserPlus,
  MessageSquare,
  Filter,
  Search,
  MoreHorizontal
} from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';

interface Lead {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  source: string;
  status: 'new' | 'contacted' | 'interested' | 'converted' | 'lost';
  interest: string;
  notes?: string;
  created_at: string;
  last_contact?: string;
}

interface LeadsManagerProps {
  clinicId?: string;
}

export const LeadsManager: React.FC<LeadsManagerProps> = ({ clinicId }) => {
  const { toast } = useToast();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showAddLead, setShowAddLead] = useState(false);
  const [newLead, setNewLead] = useState({
    name: '',
    email: '',
    phone: '',
    source: '',
    interest: '',
    notes: ''
  });

  // Dados simulados para demonstração
  useEffect(() => {
    const mockLeads: Lead[] = [
      {
        id: '1',
        name: 'Maria Silva',
        email: 'maria@email.com',
        phone: '(11) 99999-1234',
        source: 'Google Ads',
        status: 'new',
        interest: 'Ortodontia',
        notes: 'Interessada em aparelho invisível',
        created_at: new Date().toISOString(),
      },
      {
        id: '2',
        name: 'João Santos',
        email: 'joao@email.com',
        phone: '(11) 98888-5678',
        source: 'Facebook',
        status: 'contacted',
        interest: 'Clareamento',
        notes: 'Já foi contatado via WhatsApp',
        created_at: new Date(Date.now() - 86400000).toISOString(),
        last_contact: new Date().toISOString()
      },
      {
        id: '3',
        name: 'Ana Costa',
        email: 'ana@email.com',
        phone: '(11) 97777-9012',
        source: 'Site',
        status: 'converted',
        interest: 'Implante',
        notes: 'Agendou consulta para próxima semana',
        created_at: new Date(Date.now() - 172800000).toISOString(),
        last_contact: new Date(Date.now() - 86400000).toISOString()
      }
    ];
    setLeads(mockLeads);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'contacted': return 'bg-yellow-100 text-yellow-800';
      case 'interested': return 'bg-purple-100 text-purple-800';
      case 'converted': return 'bg-green-100 text-green-800';
      case 'lost': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'new': return 'Novo';
      case 'contacted': return 'Contatado';
      case 'interested': return 'Interessado';
      case 'converted': return 'Convertido';
      case 'lost': return 'Perdido';
      default: return status;
    }
  };

  const addLead = () => {
    if (!newLead.name.trim()) {
      toast({
        title: 'Erro',
        description: 'Nome é obrigatório',
        variant: 'destructive'
      });
      return;
    }

    const lead: Lead = {
      id: Date.now().toString(),
      ...newLead,
      status: 'new',
      created_at: new Date().toISOString()
    };

    setLeads(prev => [lead, ...prev]);
    setNewLead({
      name: '',
      email: '',
      phone: '',
      source: '',
      interest: '',
      notes: ''
    });
    setShowAddLead(false);

    toast({
      title: 'Sucesso',
      description: 'Lead adicionado com sucesso!'
    });
  };

  const updateLeadStatus = (leadId: string, newStatus: Lead['status']) => {
    setLeads(prev => prev.map(lead => 
      lead.id === leadId 
        ? { ...lead, status: newStatus, last_contact: new Date().toISOString() }
        : lead
    ));

    toast({
      title: 'Status atualizado',
      description: `Status do lead alterado para ${getStatusText(newStatus)}`
    });
  };

  const filteredLeads = leads.filter(lead => {
    const matchesSearch = lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lead.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lead.phone?.includes(searchTerm);
    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: leads.length,
    new: leads.filter(l => l.status === 'new').length,
    contacted: leads.filter(l => l.status === 'contacted').length,
    converted: leads.filter(l => l.status === 'converted').length,
    conversionRate: leads.length > 0 ? ((leads.filter(l => l.status === 'converted').length / leads.length) * 100).toFixed(1) : '0'
  };

  return (
    <div className="w-full max-w-none space-y-4 sm:space-y-6 p-4 sm:p-6">
      {/* Estatísticas */}
      <div className="w-full grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Card className="w-full min-w-0">
          <CardContent className="p-3 sm:p-4">
            <div className="text-center">
              <div className="text-lg sm:text-2xl font-bold text-blue-600">{stats.new}</div>
              <div className="text-xs sm:text-sm text-blue-800 truncate">Novos Leads</div>
            </div>
          </CardContent>
        </Card>
        <Card className="w-full min-w-0">
          <CardContent className="p-3 sm:p-4">
            <div className="text-center">
              <div className="text-lg sm:text-2xl font-bold text-yellow-600">{stats.contacted}</div>
              <div className="text-xs sm:text-sm text-yellow-800 truncate">Em Contato</div>
            </div>
          </CardContent>
        </Card>
        <Card className="w-full min-w-0">
          <CardContent className="p-3 sm:p-4">
            <div className="text-center">
              <div className="text-lg sm:text-2xl font-bold text-green-600">{stats.converted}</div>
              <div className="text-xs sm:text-sm text-green-800 truncate">Convertidos</div>
            </div>
          </CardContent>
        </Card>
        <Card className="w-full min-w-0">
          <CardContent className="p-3 sm:p-4">
            <div className="text-center">
              <div className="text-lg sm:text-2xl font-bold text-gray-600">{stats.conversionRate}%</div>
              <div className="text-xs sm:text-sm text-gray-800 truncate">Taxa de Conversão</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Ações */}
      <Card className="w-full">
        <CardHeader>
          <div className="w-full flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Gestão de Leads
            </CardTitle>
            <Dialog open={showAddLead} onOpenChange={setShowAddLead}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2 w-full sm:w-auto">
                  <UserPlus className="h-4 w-4" />
                  <span className="sm:inline">Novo Lead</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Adicionar Novo Lead</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Nome *"
                    value={newLead.name}
                    onChange={(e) => setNewLead(prev => ({ ...prev, name: e.target.value }))}
                  />
                  <Input
                    placeholder="Email"
                    type="email"
                    value={newLead.email}
                    onChange={(e) => setNewLead(prev => ({ ...prev, email: e.target.value }))}
                  />
                  <Input
                    placeholder="Telefone"
                    value={newLead.phone}
                    onChange={(e) => setNewLead(prev => ({ ...prev, phone: e.target.value }))}
                  />
                  <Input
                    placeholder="Fonte (Google, Facebook, Site...)"
                    value={newLead.source}
                    onChange={(e) => setNewLead(prev => ({ ...prev, source: e.target.value }))}
                  />
                  <Input
                    placeholder="Interesse (Ortodontia, Implante...)"
                    value={newLead.interest}
                    onChange={(e) => setNewLead(prev => ({ ...prev, interest: e.target.value }))}
                  />
                  <Textarea
                    placeholder="Observações"
                    value={newLead.notes}
                    onChange={(e) => setNewLead(prev => ({ ...prev, notes: e.target.value }))}
                  />
                  <div className="flex gap-2">
                    <Button onClick={addLead}>Adicionar</Button>
                    <Button variant="outline" onClick={() => setShowAddLead(false)}>
                      Cancelar
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="w-full flex flex-col sm:flex-row gap-3 sm:gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar leads..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="new">Novos</SelectItem>
                <SelectItem value="contacted">Contatados</SelectItem>
                <SelectItem value="interested">Interessados</SelectItem>
                <SelectItem value="converted">Convertidos</SelectItem>
                <SelectItem value="lost">Perdidos</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Lista de Leads */}
          <div className="w-full space-y-4">
            {filteredLeads.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {leads.length === 0 ? 'Nenhum lead cadastrado' : 'Nenhum lead encontrado'}
              </div>
            ) : (
              filteredLeads.map((lead) => (
                <Card key={lead.id} className="w-full">
                  <CardContent className="p-3 sm:p-4">
                    <div className="w-full flex flex-col sm:flex-row justify-between items-start gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2">
                          <h3 className="font-semibold truncate">{lead.name}</h3>
                          <Badge className={getStatusColor(lead.status)}>
                            {getStatusText(lead.status)}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
                          {lead.email && (
                            <div className="flex items-center gap-2 min-w-0">
                              <Mail className="h-4 w-4 flex-shrink-0" />
                              <span className="truncate">{lead.email}</span>
                            </div>
                          )}
                          {lead.phone && (
                            <div className="flex items-center gap-2 min-w-0">
                              <Phone className="h-4 w-4 flex-shrink-0" />
                              <span className="truncate">{lead.phone}</span>
                            </div>
                          )}
                          <div className="truncate">Fonte: {lead.source || 'Não informado'}</div>
                          <div className="truncate">Interesse: {lead.interest || 'Não informado'}</div>
                        </div>
                        {lead.notes && (
                          <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{lead.notes}</p>
                        )}
                      </div>
                      <div className="flex-shrink-0 self-start">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => updateLeadStatus(lead.id, 'contacted')}>
                              Marcar como Contatado
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => updateLeadStatus(lead.id, 'interested')}>
                              Marcar como Interessado
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => updateLeadStatus(lead.id, 'converted')}>
                              Marcar como Convertido
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => updateLeadStatus(lead.id, 'lost')}>
                              Marcar como Perdido
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};