import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Upload, Edit, MapPin, Lock, Building2, Camera } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { ImageUpload } from '@/components/ui/ImageUpload';
import { 
  processImageComplete, 
  ImageValidationOptions, 
  ImageProcessingOptions, 
  ThumbnailOptions,
  ProcessedImage,
  cleanupPreviewUrl
} from '@/utils/imageProcessor';

interface ClinicData {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  logo_url?: string;
  address?: any;
  city?: string;
  owner_id?: string;
  master_user_id?: string;
}

interface AddressData {
  street: string;
  number: string;
  neighborhood: string;
  city: string;
  state: string;
  zip_code: string;
}

// Lista de estados brasileiros
const BRAZILIAN_STATES = [
  { code: 'AC', name: 'Acre' },
  { code: 'AL', name: 'Alagoas' },
  { code: 'AP', name: 'Amapá' },
  { code: 'AM', name: 'Amazonas' },
  { code: 'BA', name: 'Bahia' },
  { code: 'CE', name: 'Ceará' },
  { code: 'DF', name: 'Distrito Federal' },
  { code: 'ES', name: 'Espírito Santo' },
  { code: 'GO', name: 'Goiás' },
  { code: 'MA', name: 'Maranhão' },
  { code: 'MT', name: 'Mato Grosso' },
  { code: 'MS', name: 'Mato Grosso do Sul' },
  { code: 'MG', name: 'Minas Gerais' },
  { code: 'PA', name: 'Pará' },
  { code: 'PB', name: 'Paraíba' },
  { code: 'PR', name: 'Paraná' },
  { code: 'PE', name: 'Pernambuco' },
  { code: 'PI', name: 'Piauí' },
  { code: 'RJ', name: 'Rio de Janeiro' },
  { code: 'RN', name: 'Rio Grande do Norte' },
  { code: 'RS', name: 'Rio Grande do Sul' },
  { code: 'RO', name: 'Rondônia' },
  { code: 'RR', name: 'Roraima' },
  { code: 'SC', name: 'Santa Catarina' },
  { code: 'SP', name: 'São Paulo' },
  { code: 'SE', name: 'Sergipe' },
  { code: 'TO', name: 'Tocantins' }
];

export default function ClinicProfileManager() {
  const { user } = useAuth();
  const [clinic, setClinic] = useState<ClinicData | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [editingName, setEditingName] = useState(false);
  const [editingAddress, setEditingAddress] = useState(false);
  const [editingPassword, setEditingPassword] = useState(false);
  const [processedImages, setProcessedImages] = useState<ProcessedImage[]>([]);
  
  // Dados do formulário
  const [clinicName, setClinicName] = useState('');
  const [address, setAddress] = useState<AddressData>({
    street: '',
    number: '',
    neighborhood: '',
    city: '',
    state: '',
    zip_code: ''
  });
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    if (user) {
      fetchClinicData();
    }
  }, [user]);

  const fetchClinicData = async () => {
    try {
      setLoading(true);
      
      // Buscar clínica do usuário
      const { data: clinicData, error: clinicError } = await supabase
        .from('clinics')
        .select('*')
        .eq('master_user_id', user?.id)
        .maybeSingle();

      if (clinicError || !clinicData) {
        // Tentar com owner_id se master_user_id falhou
        const { data: clinicData2, error: clinicError2 } = await supabase
          .from('clinics')
          .select('*')
          .eq('owner_id', user?.id)
          .maybeSingle();
        
        if (clinicError2 || !clinicData2) {
          toast.error('Clínica não encontrada');
          return;
        }
        
        setClinic(clinicData2);
        setClinicName(clinicData2.name || '');
        loadAddressData(clinicData2);
      } else {
        setClinic(clinicData);
        setClinicName(clinicData.name || '');
        loadAddressData(clinicData);
      }
    } catch (error) {
      console.error('Erro ao carregar dados da clínica:', error);
      toast.error('Erro ao carregar dados da clínica');
    } finally {
      setLoading(false);
    }
  };

  const loadAddressData = (clinicData: ClinicData) => {
    if (clinicData.address) {
      const addressData = typeof clinicData.address === 'string' 
        ? JSON.parse(clinicData.address) 
        : clinicData.address;
      
      setAddress({
        street: addressData.street || '',
        number: addressData.number || '',
        neighborhood: addressData.neighborhood || '',
        city: clinicData.city || addressData.city || '',
        state: addressData.state || '',
        zip_code: addressData.zip_code || ''
      });
    }
  };

  const handleImageUpload = async (file: File) => {
    if (!clinic?.id) {
      toast.error('ID da clínica não encontrado');
      return;
    }
    
    try {
      setUploading(true);
      setUploadProgress(10);
      
      // Configurações de validação e processamento
      const validationOptions: ImageValidationOptions = {
        maxWidth: 2048,
        maxHeight: 2048,
        minWidth: 200,
        minHeight: 200,
        maxSizeBytes: 5 * 1024 * 1024, // 5MB
        allowedFormats: ['image/jpeg', 'image/png', 'image/webp']
      };
      
      const processingOptions: ImageProcessingOptions = {
        maxWidth: 1024,
        maxHeight: 1024,
        quality: 0.85,
        format: 'jpeg'
      };
      
      const thumbnailOptions: ThumbnailOptions = {
        width: 150,
        height: 150,
        quality: 0.8
      };
      
      setUploadProgress(20);
      
      // Processar imagem completa
      const processedImage = await processImageComplete(
        file,
        validationOptions,
        processingOptions,
        thumbnailOptions
      );
      
      setUploadProgress(50);
      
      // Upload da imagem principal
      const timestamp = Date.now();
      const mainFileName = `${clinic.id}-logo-${timestamp}.jpg`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('profile-images')
        .upload(mainFileName, processedImage.file);

      if (uploadError) {
        throw new Error(`Erro no upload: ${uploadError.message}`);
      }
      
      setUploadProgress(70);
      
      // Upload do thumbnail se disponível
      let thumbnailUrl = '';
      if (processedImage.thumbnail) {
        const thumbFileName = `${clinic.id}-logo-thumb-${timestamp}.jpg`;
        
        const { error: thumbError } = await supabase.storage
          .from('profile-images')
          .upload(thumbFileName, processedImage.thumbnail);
          
        if (!thumbError) {
          const { data: { publicUrl: thumbPublicUrl } } = supabase.storage
            .from('profile-images')
            .getPublicUrl(thumbFileName);
          thumbnailUrl = thumbPublicUrl;
        }
      }
      
      setUploadProgress(85);

      // Obter URL pública da imagem principal
      const { data: { publicUrl } } = supabase.storage
        .from('profile-images')
        .getPublicUrl(mainFileName);

      // Atualizar banco de dados
      const updateData: any = { logo_url: publicUrl };
      if (thumbnailUrl) {
        updateData.logo_thumbnail_url = thumbnailUrl;
      }
      
      const { error } = await supabase
        .from('clinics')
        .update(updateData)
        .eq('id', clinic.id);
      
      if (error) {
        throw new Error(`Erro ao salvar logo: ${error.message}`);
      }
      
      setUploadProgress(100);
      
      // Limpar preview
      cleanupPreviewUrl(processedImage.preview);
      
      toast.success('Logo atualizado com sucesso!');
      
      // Atualizar dados da clínica imediatamente
      setClinic(prev => prev ? { ...prev, logo_url: publicUrl } : null);
      
      // Buscar dados atualizados do servidor
      setTimeout(() => {
        fetchClinicData();
        setUploadProgress(0);
      }, 1000);
      
    } catch (error: any) {
      console.error('Erro ao fazer upload da imagem:', error);
      toast.error(error.message || 'Erro ao fazer upload da imagem');
      setUploadProgress(0);
    } finally {
      setUploading(false);
    }
  };

  const saveClinicName = async () => {
    if (!clinic?.id) {
      toast.error('ID da clínica não encontrado');
      return;
    }
    
    if (!clinicName.trim()) {
      toast.error('Nome da clínica é obrigatório');
      return;
    }
    
    try {
      const { error } = await supabase
        .from('clinics')
        .update({ name: clinicName.trim() })
        .eq('id', clinic.id);
      
      if (error) {
        console.error('Erro detalhado ao salvar nome:', error);
        throw error;
      }

      toast.success('Nome da clínica atualizado com sucesso!');
      setEditingName(false);
      fetchClinicData();
    } catch (error) {
      console.error('Erro ao salvar nome:', error);
      toast.error(`Erro ao salvar nome da clínica: ${error.message || 'Erro desconhecido'}`);
    }
  };

  const saveAddress = async () => {
    if (!clinic?.id) return;
    
    try {
      const addressData = {
        street: address.street,
        number: address.number,
        neighborhood: address.neighborhood,
        city: address.city,
        state: address.state,
        zip_code: address.zip_code
      };

      const { error } = await supabase
        .from('clinics')
        .update({
          address: addressData,
          city: address.city
        })
        .eq('id', clinic.id);

      if (error) {
        console.error('Erro detalhado ao salvar endereço:', error);
        throw error;
      }

      toast.success('Endereço atualizado com sucesso!');
      setEditingAddress(false);
      fetchClinicData();
    } catch (error) {
      console.error('Erro ao salvar endereço:', error);
      toast.error(`Erro ao salvar endereço: ${error.message || 'Erro desconhecido'}`);
    }
  };

  const changePassword = async () => {
    if (!passwordData.newPassword || !passwordData.confirmPassword) {
      toast.error('Preencha todos os campos de senha');
      return;
    }
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('As senhas não coincidem');
      return;
    }
    
    if (passwordData.newPassword.length < 6) {
      toast.error('A senha deve ter pelo menos 6 caracteres');
      return;
    }
    
    try {
      const { error } = await supabase.auth.updateUser({
        password: passwordData.newPassword
      });
      
      if (error) throw error;

      toast.success('Senha alterada com sucesso!');
      setEditingPassword(false);
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error) {
      console.error('Erro ao alterar senha:', error);
      toast.error('Erro ao alterar senha');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Carregando dados da clínica...</p>
        </div>
      </div>
    );
  }

  if (!clinic) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Clínica não encontrada</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Building2 className="h-8 w-8 text-primary" />
        <h1 className="text-3xl font-bold">Perfil da Clínica</h1>
      </div>

      {/* Logo da Clínica */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Logo da Clínica
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ImageUpload
            onImageSelect={handleImageUpload}
            currentImageUrl={clinic.logo_url}
            uploading={uploading}
            uploadProgress={uploadProgress}
            maxSizeMB={5}
            previewSize="lg"
            label="Logo da Clínica"
            description="Selecione uma imagem para o logo (PNG, JPG, WebP até 5MB)"
            showPreview={true}
          />
        </CardContent>
      </Card>

      {/* Nome da Clínica */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Nome da Clínica
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setEditingName(!editingName)}
            >
              <Edit className="h-4 w-4 mr-2" />
              Editar
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {editingName ? (
            <div className="space-y-4">
              <Input
                value={clinicName}
                onChange={(e) => setClinicName(e.target.value)}
                placeholder="Nome da clínica"
              />
              <div className="flex gap-2">
                <Button onClick={saveClinicName}>
                  Salvar
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setEditingName(false);
                    setClinicName(clinic.name || '');
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-lg font-medium">{clinic.name || 'Nome não informado'}</p>
          )}
        </CardContent>
      </Card>

      {/* Endereço Completo */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Endereço Completo
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setEditingAddress(!editingAddress)}
            >
              <Edit className="h-4 w-4 mr-2" />
              Editar
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {editingAddress ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="street">Rua/Avenida</Label>
                  <Input
                    id="street"
                    value={address.street}
                    onChange={(e) => setAddress(prev => ({...prev, street: e.target.value}))}
                    placeholder="Nome da rua ou avenida"
                  />
                </div>
                <div>
                  <Label htmlFor="number">Número</Label>
                  <Input
                    id="number"
                    value={address.number}
                    onChange={(e) => setAddress(prev => ({...prev, number: e.target.value}))}
                    placeholder="Número"
                  />
                </div>
                <div>
                  <Label htmlFor="neighborhood">Bairro</Label>
                  <Input
                    id="neighborhood"
                    value={address.neighborhood}
                    onChange={(e) => setAddress(prev => ({...prev, neighborhood: e.target.value}))}
                    placeholder="Nome do bairro"
                  />
                </div>
                <div>
                  <Label htmlFor="zip_code">CEP</Label>
                  <Input
                    id="zip_code"
                    value={address.zip_code}
                    onChange={(e) => setAddress(prev => ({...prev, zip_code: e.target.value}))}
                    placeholder="00000-000"
                  />
                </div>
                <div>
                  <Label htmlFor="city">Cidade</Label>
                  <Input
                    id="city"
                    value={address.city}
                    onChange={(e) => setAddress(prev => ({...prev, city: e.target.value}))}
                    placeholder="Nome da cidade"
                  />
                </div>
                <div>
                  <Label htmlFor="state">Estado</Label>
                  <Select 
                    value={address.state} 
                    onValueChange={(value) => setAddress(prev => ({...prev, state: value}))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o estado" />
                    </SelectTrigger>
                    <SelectContent>
                      {BRAZILIAN_STATES.map((state) => (
                        <SelectItem key={state.code} value={state.code}>
                          {state.name} ({state.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={saveAddress}>
                  Salvar Endereço
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setEditingAddress(false);
                    loadAddressData(clinic);
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <p><strong>Endereço:</strong> {address.street} {address.number}</p>
              <p><strong>Bairro:</strong> {address.neighborhood}</p>
              <p><strong>Cidade:</strong> {address.city}</p>
              <p><strong>Estado:</strong> {BRAZILIAN_STATES.find(s => s.code === address.state)?.name || address.state}</p>
              <p><strong>CEP:</strong> {address.zip_code}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Alterar Senha */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Alterar Senha
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setEditingPassword(!editingPassword)}
            >
              <Edit className="h-4 w-4 mr-2" />
              Alterar
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {editingPassword ? (
            <div className="space-y-4">
              <div>
                <Label htmlFor="newPassword">Nova Senha</Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData(prev => ({...prev, newPassword: e.target.value}))}
                  placeholder="Digite a nova senha"
                />
              </div>
              <div>
                <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData(prev => ({...prev, confirmPassword: e.target.value}))}
                  placeholder="Confirme a nova senha"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={changePassword}>
                  Alterar Senha
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setEditingPassword(false);
                    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-muted-foreground">
              Clique em "Alterar" para modificar sua senha de acesso.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}