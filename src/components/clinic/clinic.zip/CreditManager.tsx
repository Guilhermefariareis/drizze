import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  CreditCard, 
  TrendingUp,
  DollarSign,
  Users,
  Clock,
  CheckCircle,
  AlertCircle,
  Settings,
  FileText,
  Calendar,
  Search
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';

interface CreditRequest {
  id: string;
  patient_name: string;
  patient_email: string;
  requested_amount: number;
  approved_amount?: number;
  installments: number;
  interest_rate: number;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  treatment: string;
  created_at: string;
  decision_date?: string;
  notes?: string;
}

interface CreditSettings {
  max_amount: number;
  min_amount: number;
  max_installments: number;
  interest_rate: number;
  approval_limit: number;
}

interface CreditManagerProps {
  clinicId?: string;
}

export const CreditManager: React.FC<CreditManagerProps> = ({ clinicId }) => {
  const { toast } = useToast();
  const [requests, setRequests] = useState<CreditRequest[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState<CreditSettings>({
    max_amount: 50000,
    min_amount: 500,
    max_installments: 48,
    interest_rate: 2.5,
    approval_limit: 10000
  });

  // Dados simulados para demonstração
  useEffect(() => {
    const mockRequests: CreditRequest[] = [
      {
        id: '1',
        patient_name: 'Maria Silva',
        patient_email: 'maria@email.com',
        requested_amount: 8500,
        approved_amount: 8000,
        installments: 24,
        interest_rate: 2.5,
        status: 'approved',
        treatment: 'Ortodontia completa',
        created_at: new Date().toISOString(),
        decision_date: new Date().toISOString(),
        notes: 'Cliente com bom histórico creditício'
      },
      {
        id: '2',
        patient_name: 'João Santos',
        patient_email: 'joao@email.com',
        requested_amount: 15000,
        installments: 36,
        interest_rate: 2.5,
        status: 'pending',
        treatment: 'Implantes dentários',
        created_at: new Date(Date.now() - 86400000).toISOString(),
        notes: 'Aguardando análise de documentos'
      },
      {
        id: '3',
        patient_name: 'Ana Costa',
        patient_email: 'ana@email.com',
        requested_amount: 3500,
        approved_amount: 3500,
        installments: 12,
        interest_rate: 2.5,
        status: 'paid',
        treatment: 'Clareamento + Lentes',
        created_at: new Date(Date.now() - 172800000).toISOString(),
        decision_date: new Date(Date.now() - 86400000).toISOString(),
        notes: 'Pagamento finalizado com sucesso'
      }
    ];
    setRequests(mockRequests);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'paid': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'approved': return 'Aprovado';
      case 'rejected': return 'Rejeitado';
      case 'paid': return 'Pago';
      default: return status;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return Clock;
      case 'approved': return CheckCircle;
      case 'rejected': return AlertCircle;
      case 'paid': return CheckCircle;
      default: return Clock;
    }
  };

  const updateRequestStatus = (requestId: string, newStatus: CreditRequest['status'], approvedAmount?: number) => {
    setRequests(prev => prev.map(request => 
      request.id === requestId 
        ? { 
            ...request, 
            status: newStatus, 
            decision_date: new Date().toISOString(),
            approved_amount: approvedAmount || request.approved_amount
          }
        : request
    ));

    toast({
      title: 'Status atualizado',
      description: `Solicitação ${getStatusText(newStatus).toLowerCase()}`
    });
  };

  const filteredRequests = requests.filter(request => {
    const matchesSearch = request.patient_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.patient_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.treatment.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || request.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: requests.length,
    pending: requests.filter(r => r.status === 'pending').length,
    approved: requests.filter(r => r.status === 'approved').length,
    totalApproved: requests
      .filter(r => r.status === 'approved' || r.status === 'paid')
      .reduce((sum, r) => sum + (r.approved_amount || 0), 0),
    approvalRate: requests.length > 0 ? 
      ((requests.filter(r => r.status === 'approved' || r.status === 'paid').length / requests.length) * 100).toFixed(1) : '0'
  };

  const saveSettings = () => {
    toast({
      title: 'Configurações salvas',
      description: 'As configurações de crédito foram atualizadas'
    });
    setShowSettings(false);
  };

  return (
    <div className="w-full max-w-none space-y-6">
      {/* Estatísticas */}
      <div className="w-full grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="w-full">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
              <div className="text-sm text-yellow-800">Aguardando Análise</div>
            </div>
          </CardContent>
        </Card>
        <Card className="w-full">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.approved}</div>
              <div className="text-sm text-green-800">Aprovadas</div>
            </div>
          </CardContent>
        </Card>
        <Card className="w-full">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                R$ {stats.totalApproved.toLocaleString()}
              </div>
              <div className="text-sm text-blue-800">Crédito Aprovado</div>
            </div>
          </CardContent>
        </Card>
        <Card className="w-full">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-600">{stats.approvalRate}%</div>
              <div className="text-sm text-gray-800">Taxa de Aprovação</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sistema de Crédito */}
      <Card className="w-full">
        <CardHeader>
          <div className="w-full flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Crédito Odontológico
            </CardTitle>
            <div className="flex gap-2">
              <Dialog open={showSettings} onOpenChange={setShowSettings}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4 mr-2" />
                    Configurações
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Configurações de Crédito</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Valor Mínimo (R$)</label>
                      <Input
                        type="number"
                        value={settings.min_amount}
                        onChange={(e) => setSettings(prev => ({ ...prev, min_amount: Number(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Valor Máximo (R$)</label>
                      <Input
                        type="number"
                        value={settings.max_amount}
                        onChange={(e) => setSettings(prev => ({ ...prev, max_amount: Number(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Máximo de Parcelas</label>
                      <Input
                        type="number"
                        value={settings.max_installments}
                        onChange={(e) => setSettings(prev => ({ ...prev, max_installments: Number(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Taxa de Juros (%/mês)</label>
                      <Input
                        type="number"
                        step="0.1"
                        value={settings.interest_rate}
                        onChange={(e) => setSettings(prev => ({ ...prev, interest_rate: Number(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Limite para Aprovação Automática (R$)</label>
                      <Input
                        type="number"
                        value={settings.approval_limit}
                        onChange={(e) => setSettings(prev => ({ ...prev, approval_limit: Number(e.target.value) }))}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={saveSettings}>Salvar</Button>
                      <Button variant="outline" onClick={() => setShowSettings(false)}>
                        Cancelar
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <Button size="sm">
                <FileText className="h-4 w-4 mr-2" />
                Relatório
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Status do Sistema */}
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-green-900">Sistema de Crédito Ativo</p>
                <p className="text-sm text-green-700">
                  Limite atual: R$ {settings.max_amount.toLocaleString()} | 
                  Taxa: {settings.interest_rate}% a.m. | 
                  Até {settings.max_installments}x
                </p>
              </div>
              <Badge className="bg-green-100 text-green-800">Ativo</Badge>
            </div>
          </div>

          {/* Filtros */}
          <div className="w-full flex gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar solicitações..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="pending">Pendentes</SelectItem>
                <SelectItem value="approved">Aprovadas</SelectItem>
                <SelectItem value="rejected">Rejeitadas</SelectItem>
                <SelectItem value="paid">Pagas</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Lista de Solicitações */}
          <div className="w-full space-y-4">
            {filteredRequests.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {requests.length === 0 ? 'Nenhuma solicitação encontrada' : 'Nenhuma solicitação corresponde aos filtros'}
              </div>
            ) : (
              filteredRequests.map((request) => {
                const StatusIcon = getStatusIcon(request.status);
                return (
                  <Card key={request.id} className="w-full">
                    <CardContent className="p-4">
                      <div className="w-full flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold">{request.patient_name}</h3>
                            <Badge className={getStatusColor(request.status)}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {getStatusText(request.status)}
                            </Badge>
                          </div>
                          <div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="font-medium">Valor Solicitado:</span>
                              <div className="text-lg font-bold text-blue-600">
                                R$ {request.requested_amount.toLocaleString()}
                              </div>
                            </div>
                            {request.approved_amount && (
                              <div>
                                <span className="font-medium">Valor Aprovado:</span>
                                <div className="text-lg font-bold text-green-600">
                                  R$ {request.approved_amount.toLocaleString()}
                                </div>
                              </div>
                            )}
                            <div>
                              <span className="font-medium">Parcelas:</span>
                              <div>{request.installments}x de R$ {
                                ((request.approved_amount || request.requested_amount) / request.installments).toLocaleString()
                              }</div>
                            </div>
                            <div>
                              <span className="font-medium">Tratamento:</span>
                              <div>{request.treatment}</div>
                            </div>
                            <div>
                              <span className="font-medium">Data:</span>
                              <div>{new Date(request.created_at).toLocaleDateString()}</div>
                            </div>
                            <div>
                              <span className="font-medium">Taxa:</span>
                              <div>{request.interest_rate}% a.m.</div>
                            </div>
                          </div>
                          {request.notes && (
                            <p className="text-sm text-muted-foreground mt-2 p-2 bg-gray-50 rounded">
                              {request.notes}
                            </p>
                          )}
                        </div>
                        {request.status === 'pending' && (
                          <div className="flex flex-col gap-2 ml-4">
                            <Button 
                              size="sm" 
                              onClick={() => updateRequestStatus(request.id, 'approved', request.requested_amount)}
                            >
                              Aprovar
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => updateRequestStatus(request.id, 'rejected')}
                            >
                              Rejeitar
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};