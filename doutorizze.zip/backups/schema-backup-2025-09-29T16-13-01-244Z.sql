-- Backup do Schema do Supabase
-- Gerado em: 2025-09-29T16-13-01-244Z

-- Tabela: profiles
-- Schema básico - tabela existe e é acessível
-- Tabela verificada e acessível

-- Tabela: clinics
-- Schema básico - tabela existe e é acessível
-- Tabela verificada e acessível

-- Tabela: credit_requests
-- Schema básico - tabela existe e é acessível
-- Tabela verificada e acessível

-- Tabela: subscription_plans
-- Schema básico - tabela existe e é acessível
-- Tabela verificada e acessível

-- Tabela: subscriptions
-- Schema básico - tabela existe e é acessível
-- Tabela verificada e acessível

