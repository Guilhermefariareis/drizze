import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CalendarioPrincipal } from '@/components/agendamento/CalendarioPrincipal';
import FormularioAgendamento from '@/components/agendamento/FormularioAgendamento';
import { ListaAgendamentos } from '@/components/agendamento/ListaAgendamentos';
import { ModalAgendamento } from '@/components/agendamento/ModalAgendamento';
import useAgendamentos, { type Agendamento } from '@/hooks/useAgendamentos';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  Calendar, 
  Plus, 
  BarChart3, 
  Clock, 
  Users, 
  DollarSign,
  TrendingUp,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek } from 'date-fns';
import { ptBR } from 'date-fns/locale';

import { toast } from 'sonner';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { AppSidebar } from '@/components/AppSidebar';

const AgendamentosPage: React.FC = () => {
  console.log('🚨 [CRÍTICO] AgendamentosPage CARREGADA');
  
  const { user } = useAuth();
  const { clinicaId: clinicaIdFromUrl } = useParams<{ clinicaId?: string }>();
  const [clinicaId, setClinicaId] = useState<string>(clinicaIdFromUrl || '');
  const [modalAberto, setModalAberto] = useState(false);
  const [agendamentoEdicao, setAgendamentoEdicao] = useState<Agendamento | undefined>();
  const [abaSelecionada, setAbaSelecionada] = useState('calendario');
  const navigate = useNavigate();
  const [agendamentoVisualizando, setAgendamentoVisualizando] = useState<Agendamento | null>(null);
  const [showModal, setShowModal] = useState(false);
  
  console.warn('🔄 AGENDAMENTOS PAGE LOADED');
  console.warn('👤 User ID:', user?.id);
  console.warn('🏥 Clinic ID from URL:', clinicaIdFromUrl);
  console.warn('🏥 Clinic ID state:', clinicaId);
  console.warn('🌐 Current URL:', window.location.pathname);
  
  console.log('🚨 [CRÍTICO] AgendamentosPage - Inicializando useAgendamentos');
  const {
    agendamentos,
    loading,
    criarAgendamento,
    atualizarAgendamento,
    obterEstatisticas,
    setFiltros
  } = useAgendamentos();
  console.log('🚨 [CRÍTICO] AgendamentosPage - useAgendamentos inicializado, agendamentos:', agendamentos.length);

  // Buscar clínica do usuário (apenas se não tiver clinicaId da URL)
  useEffect(() => {
    const buscarClinica = async () => {
      if (!user?.id) return;
      
      // Se já temos clinicaId da URL, não precisa buscar
      if (clinicaIdFromUrl) {
        console.log('🔍 [AgendamentosPage] Usando clinicaId da URL:', clinicaIdFromUrl);
        setClinicaId(clinicaIdFromUrl);
        return;
      }
      
      try {
        console.log('🔍 [AgendamentosPage] Buscando clínica para usuário:', user.id);
        
        const { data: clinicas, error } = await supabase
          .from('clinics')
          .select('*')
          .or(`master_user_id.eq.${user.id},owner_id.eq.${user.id}`)
          .limit(1);

        if (error) {
          console.error('❌ [AgendamentosPage] Erro ao buscar clínica:', error);
          return;
        }

        if (!clinicas || clinicas.length === 0) {
          console.error('❌ [AgendamentosPage] Nenhuma clínica encontrada para o usuário');
          return;
        }

        const clinica = clinicas[0];
        console.log('✅ [AgendamentosPage] Clínica encontrada:', clinica);
        console.log('🆔 [AgendamentosPage] ClinicaId definido como:', clinica.id);
        setClinicaId(clinica.id);
      } catch (error) {
        console.error('❌ [AgendamentosPage] Erro na busca da clínica:', error);
      }
    };

    buscarClinica();
  }, [user?.id, clinicaIdFromUrl]);

  // Aplicar filtro de clínica quando clinicaId estiver disponível
  useEffect(() => {
    if (clinicaId) {
      console.log('🔍 [DEBUG] AgendamentosPage - Aplicando filtro de clínica:', clinicaId);
      setFiltros({ clinicaId });
    }
  }, [clinicaId, setFiltros]);

  const estatisticas = obterEstatisticas();

  const handleNovoAgendamento = () => {
    console.log('🔍 [DEBUG] AgendamentosPage - handleNovoAgendamento - clinicaId atual:', clinicaId);
    console.log('🔍 [DEBUG] AgendamentosPage - handleNovoAgendamento - clinicaId é vazio?', clinicaId === '');
    
    if (!clinicaId) {
      console.error('❌ [DEBUG] AgendamentosPage - ERRO: clinicaId está vazio ao tentar criar agendamento!');
      toast.error('Aguarde o carregamento dos dados da clínica');
      return;
    }
    
    setAgendamentoEdicao(undefined);
    setModalAberto(true);
  };

  const handleEditarAgendamento = (agendamento: Agendamento) => {
    setAgendamentoEdicao(agendamento);
    setModalAberto(true);
  };

  const handleViewAgendamento = (agendamento: Agendamento) => {
    setAgendamentoVisualizando(agendamento);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setAgendamentoVisualizando(null);
  };

  const handleSalvarAgendamento = async (dadosAgendamento: any) => {
    try {
      console.log('🔍 [DEBUG] AgendamentosPage - Recebendo dados para salvar:', dadosAgendamento);
      console.log('🔍 [DEBUG] AgendamentosPage - Função criarAgendamento disponível:', typeof criarAgendamento);
      
      if (agendamentoEdicao) {
        console.log('🔍 [DEBUG] AgendamentosPage - Atualizando agendamento existente:', agendamentoEdicao.id);
        const resultado = await atualizarAgendamento(agendamentoEdicao.id, dadosAgendamento);
        console.log('🔍 [DEBUG] AgendamentosPage - Resultado da atualização:', resultado);
        toast.success('Agendamento atualizado com sucesso!');
      } else {
        console.log('🔍 [DEBUG] AgendamentosPage - Criando novo agendamento');
        const resultado = await criarAgendamento(dadosAgendamento);
        console.log('🔍 [DEBUG] AgendamentosPage - Resultado da criação:', resultado);
        
        if (resultado) {
          console.log('✅ [DEBUG] AgendamentosPage - Agendamento criado com sucesso!');
          toast.success('Agendamento criado com sucesso!');
        } else {
          console.log('❌ [DEBUG] AgendamentosPage - Resultado nulo/falso');
          toast.error('Erro ao criar agendamento');
          return;
        }
      }
      setModalAberto(false);
      setAgendamentoEdicao(undefined);
    } catch (error) {
      console.error('❌ [DEBUG] AgendamentosPage - Erro ao salvar agendamento:', error);
      console.error('❌ [DEBUG] AgendamentosPage - Stack trace:', error);
      toast.error('Erro ao salvar agendamento');
    }
  };

  const handleFecharModal = () => {
    setModalAberto(false);
    setAgendamentoEdicao(undefined);
  };

  // Cards de estatísticas
  const StatCard = ({ 
    title, 
    value, 
    icon: Icon, 
    color = 'blue',
    subtitle 
  }: {
    title: string;
    value: string | number;
    icon: any;
    color?: string;
    subtitle?: string;
  }) => {
    const colorClasses = {
      blue: 'bg-blue-50 text-blue-700 border-blue-200',
      green: 'bg-green-50 text-green-700 border-green-200',
      red: 'bg-red-50 text-red-700 border-red-200',
      yellow: 'bg-yellow-50 text-yellow-700 border-yellow-200',
      purple: 'bg-purple-50 text-purple-700 border-purple-200'
    };

    return (
      <Card className={`border ${colorClasses[color as keyof typeof colorClasses]}`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">{title}</p>
              <p className="text-2xl font-bold">{value}</p>
              {subtitle && (
                <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
              )}
            </div>
            <Icon className="h-8 w-8 opacity-75" />
          </div>
        </CardContent>
      </Card>
    );
  };

  if (!clinicaId) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando sistema de agendamentos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <AppSidebar />
      <div className="flex-1 flex flex-col overflow-hidden ml-0 md:ml-64">
        <Navbar />
        <div className="flex-1 overflow-auto pt-4">
          <div className="container mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => navigate('/clinic-dashboard')}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                <span className="hidden sm:inline">Voltar ao Dashboard</span>
                <span className="sm:hidden">Voltar</span>
              </Button>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Sistema de Agendamentos</h1>
                <p className="text-gray-600 mt-1">
                  Gerencie todos os agendamentos da sua clínica
                </p>
              </div>
            </div>
            
            <Button onClick={handleNovoAgendamento} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Novo Agendamento
            </Button>
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <StatCard
              title="Total de Agendamentos"
              value={estatisticas.total}
              icon={Calendar}
              color="blue"
            />
            <StatCard
              title="Pendentes"
              value={estatisticas.pendentes}
              icon={AlertCircle}
              color="yellow"
            />
            <StatCard
              title="Confirmados"
              value={estatisticas.confirmados}
              icon={CheckCircle}
              color="green"
            />
            <StatCard
              title="Concluídos"
              value={estatisticas.concluidos}
              icon={CheckCircle}
              color="purple"
            />
            <StatCard
              title="Receita"
              value={`R$ ${estatisticas.faturamentoTotal.toFixed(2).replace('.', ',')}`}
              icon={DollarSign}
              color="green"
              subtitle={`${estatisticas.concluidos} consultas`}
            />
          </div>

          {/* Conteúdo Principal */}
          <Tabs value={abaSelecionada} onValueChange={setAbaSelecionada}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="calendario" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Calendário
              </TabsTrigger>
              <TabsTrigger value="lista" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Lista
              </TabsTrigger>
              <TabsTrigger value="relatorios" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Relatórios
              </TabsTrigger>
            </TabsList>

            <TabsContent value="calendario" className="space-y-6">
              <CalendarioPrincipal
                clinicaId={clinicaId}
                onNovoAgendamento={handleNovoAgendamento}
                onEditarAgendamento={handleEditarAgendamento}
              />
            </TabsContent>

            <TabsContent value="lista" className="space-y-6">
              <ListaAgendamentos
                onEditAgendamento={handleEditarAgendamento}
                onViewAgendamento={handleViewAgendamento}
                showFilters={true}
              />
            </TabsContent>

            <TabsContent value="relatorios" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Métricas de Performance */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Métricas de Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Taxa de Ocupação</span>
                      <span className="font-medium">{estatisticas.taxaOcupacao.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Taxa de Cancelamento</span>
                      <span className="font-medium">{estatisticas.total > 0 ? ((estatisticas.cancelados / estatisticas.total) * 100).toFixed(1) : '0.0'}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Receita Média por Consulta</span>
                      <span className="font-medium">
                        R$ {estatisticas.concluidos > 0 ? (estatisticas.faturamentoTotal / estatisticas.concluidos).toFixed(2).replace('.', ',') : '0,00'}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                {/* Resumo por Status */}
                <Card>
                  <CardHeader>
                    <CardTitle>Resumo por Status</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span className="text-gray-600">Pendentes</span>
                      </div>
                      <span className="font-medium">{estatisticas.pendentes}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-gray-600">Confirmados</span>
                      </div>
                      <span className="font-medium">{estatisticas.confirmados}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                        <span className="text-gray-600">Concluídos</span>
                      </div>
                      <span className="font-medium">{estatisticas.concluidos}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span className="text-gray-600">Cancelados</span>
                      </div>
                      <span className="font-medium">{estatisticas.cancelados}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

          {/* Modal de Formulário */}
          <Dialog open={modalAberto} onOpenChange={setModalAberto}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {agendamentoEdicao ? 'Editar Agendamento' : 'Novo Agendamento'}
                </DialogTitle>
              </DialogHeader>
              
              <FormularioAgendamento
                clinicaId={clinicaId}
                agendamento={agendamentoEdicao}
                onSalvar={handleSalvarAgendamento}
                onCancelar={handleFecharModal}
                modo={agendamentoEdicao ? 'editar' : 'criar'}
                hideTypeSelection={true}
              />
            </DialogContent>
          </Dialog>

          {/* Modal de Visualização */}
          <ModalAgendamento
            agendamento={agendamentoVisualizando}
            isOpen={showModal}
            onClose={handleCloseModal}
            onEdit={(agendamento) => {
              handleCloseModal();
              handleEditarAgendamento(agendamento);
            }}
          />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgendamentosPage;