import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";

import TestimonialsSection from "@/components/TestimonialsSection";
import HowItWorks from "@/components/HowItWorks";
import CreditSimulator from "@/components/CreditSimulator";

import SacFloatingButton from "@/components/SacFloatingButton";
import { ChatWidget } from "@/components/chat/ChatWidget";
import Footer from "@/components/Footer";
 

const Index = () => {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Navbar em fluxo normal (sticky já é aplicado dentro do componente) */}
      <Navbar />

      {/* Conteúdo principal */}
  <main className="flex-1">
    <HeroSection />
    <HowItWorks />
    <TestimonialsSection />
    <section id="credit-simulator">
      <CreditSimulator />
    </section>
    <Footer />
  </main>

      {/* Chat Widget com posicionamento responsivo - afastado do SAC */}
      <ChatWidget className="fixed z-40 right-20 bottom-24 sm:right-24 sm:bottom-28" />

      {/* Botão SAC flutuante fixo */}
      <SacFloatingButton />
    </div>
  );
};

export default Index;
