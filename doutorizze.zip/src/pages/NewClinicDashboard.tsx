import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';


import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { LoadingSpinner, LoadingState } from '@/components/ui/loading-spinner';
import { ClinicDashboardMetrics } from '@/components/clinic/ClinicDashboardMetrics';
import { ServicesSection } from '@/components/clinic/ServicesSection';
import { ServicesManager } from '@/components/clinic/ServicesManager';
import { LeadsManager } from '@/components/clinic/LeadsManager';
import { CreditManager } from '@/components/clinic/CreditManager';
import { SimpleCreditManager } from '@/components/clinic/SimpleCreditManager';
import ClinicDashboard from '@/pages/clinic/ClinicDashboard'; // Versão correta com "Solicitações de Crédito"

import ClinicorpDashboard from '@/components/clinic/ClinicorpDashboard';
import ClinicorpCredentialsForm from '@/components/clinic/ClinicorpCredentialsForm';
import ClinicSupportCenter from '@/components/clinic/ClinicSupportCenter';
import ProfessionalsManager from '@/components/clinic/ProfessionalsManager';
import ClinicProfileManager from '@/components/clinic/ClinicProfileManager';
import ConfiguracaoHorariosPage from '@/pages/ConfiguracaoHorariosPage';
import RelatoriosAgendamentosPage from '@/pages/RelatoriosAgendamentosPage';
import { useUserRole } from '@/hooks/useUserRole';
import { useClinicProfile } from '@/hooks/useClinicProfile';
import { useClinicPermissions } from '@/hooks/useClinicPermissions';
import { useAdminPermissions } from '@/hooks/useAdminPermissions';
import { useSubscriptionCheck } from '@/hooks/useSubscriptionCheck';
import { AppSidebar } from '@/components/AppSidebar';
import Footer from '@/components/Footer';
import { 
  Calendar, 
  CreditCard, 
  Users, 
  TrendingUp,
  Crown,
  AlertCircle,
  ExternalLink,
  Settings,
  MapPin,
  User,
  Home,
  Info,
  Building2,
  Menu,
  X
} from 'lucide-react';
import { Navigate, useNavigate, useSearchParams } from 'react-router-dom';



const NewClinicDashboard = () => {
  console.log('🚀 [NewClinicDashboard] Componente iniciado');
  console.log('🚨 TESTE SIMPLES - COMPONENTE CARREGADO v3.0');
  console.log('🌍 [NewClinicDashboard] URL ATUAL:', window.location.href);
  const { user } = useAuth();
  console.log('🔥🔥🔥 [NewClinicDashboard] USER OBTIDO:', user?.email);
  console.log('🔥🔥🔥 [NewClinicDashboard] USER COMPLETO:', user);
  const { role, loading: roleLoading } = useUserRole();
  
  // Hook de permissões admin
  console.log('🔥🔥🔥 [NewClinicDashboard] ANTES DE CHAMAR useAdminPermissions');
  const { isAdmin, isLoading: adminLoading } = useAdminPermissions();
  console.log('🔥🔥🔥 [NewClinicDashboard] DEPOIS DE CHAMAR useAdminPermissions:', { isAdmin, adminLoading });
  
  console.log('🚨🚨🚨 [NewClinicDashboard] isAdmin:', isAdmin);
  console.log('🚨🚨🚨 [NewClinicDashboard] adminLoading:', adminLoading);
  console.log('🚨🚨🚨 [NewClinicDashboard] role:', role);
  console.log('🚨🚨🚨 [NewClinicDashboard] roleLoading:', roleLoading);
  
  // Log para verificar se o hook está sendo executado
  console.log('🏥 [NewClinicDashboard] Executando useClinicProfile, user:', user?.id, user?.email);
  const { clinic, loading: clinicLoading } = useClinicProfile();
  console.log('🏥 [NewClinicDashboard] Resultado useClinicProfile - clinic:', clinic, 'loading:', clinicLoading);
  
  console.log('🚨 [NewClinicDashboard] ADMIN DEBUG:', { isAdmin, adminLoading, role, roleLoading });
  console.log('🚨 [NewClinicDashboard] TIMESTAMP:', Date.now());
  
  const { canAccessAdvancedServices } = useClinicPermissions(clinic?.id);
  const { loading: subscriptionLoading, canAccessAdvancedServices: hasAdvancedSubscription } = useSubscriptionCheck();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [dashboardError, setDashboardError] = useState<string | null>(null);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Capturar parâmetro tab da URL
  useEffect(() => {
    const tabParam = searchParams.get('tab');
    console.log('🏥 [NewClinicDashboard] URL completa:', window.location.href);
    console.log('🏥 [NewClinicDashboard] Search params:', window.location.search);
    console.log('🏥 [NewClinicDashboard] Parâmetro tab da URL:', tabParam);
    console.log('🏥 [NewClinicDashboard] ActiveTab atual:', activeTab);
    if (tabParam) {
      setActiveTab(tabParam);
      console.log('🏥 [NewClinicDashboard] Aba definida para:', tabParam);
    }
  }, [searchParams]);

  // Log de debug em useEffect para evitar side effects durante renderização
  useEffect(() => {
    console.log('🏥 [NewClinicDashboard] Componente renderizado, activeTab:', activeTab);
    console.log('🏥 [NewClinicDashboard] Usuário:', user?.email);
    console.log('🏥 [NewClinicDashboard] Role:', role);
    console.log('🏥 [NewClinicDashboard] Clínica carregada:', clinic?.name, clinic?.id);
  }, [activeTab, user?.email, role, clinic?.name, clinic?.id]);

  // Redirecionamento se não estiver logado
  useEffect(() => {
    if (!user) {
      const currentSearchParams = searchParams.toString();
      const redirectUrl = currentSearchParams ? `/clinic-login?${currentSearchParams}` : '/clinic-login';
      navigate(redirectUrl, { replace: true });
    }
  }, [user, searchParams, navigate]);

  if (!user) {
    return null;
  }

  console.log('🔍 [NewClinicDashboard] Debug admin:', { isAdmin, adminLoading, role, roleLoading });

  // Esperar o role carregar antes de fazer qualquer redirecionamento
  if (roleLoading || !role || adminLoading) {
    console.log('🔍 [NewClinicDashboard] Aguardando carregamento:', { roleLoading, role, adminLoading });
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">Carregando...</div>
      </div>
    );
  }

  // Se for admin, redirecionar para /admin
  if (isAdmin) {
    console.log('🏥 [NewClinicDashboard] Usuário é admin, redirecionando para /admin');
    return <Navigate to="/admin" replace />;
  }

  // BYPASS TEMPORÁRIO PARA TESTE - REMOVER DEPOIS
  console.log('🔧 [NewClinicDashboard] role:', role);
  console.log('🔧 [NewClinicDashboard] clinic:', clinic);
  console.log('🔧 [NewClinicDashboard] user:', user);
  
  // CORREÇÃO CRÍTICA: Removido hardcode que causava vazamento de dados
  // Agora usa apenas a clínica real do usuário logado
  const testClinic = clinic;

  /*
  if (role !== 'clinic' && role !== 'admin') {
    return <Navigate to="/patient-dashboard" replace />;
  }

  if (clinicLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">Carregando...</div>
      </div>
    );
  }

  if (!clinic) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Configuração de Clínica</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Configure sua clínica para começar a usar o sistema.</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  */

  // Verificação de segurança: só continua se houver clínica válida OU se for admin
  if ((!testClinic || !testClinic.id) && !isAdmin) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-500" />
              Acesso Negado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-600">
              Você não tem uma clínica associada ou não tem permissão para acessar esta área.
            </p>
            <Button 
              onClick={() => navigate('/clinic-login')} 
              className="mt-4 w-full"
            >
              Fazer Login Novamente
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isMaster = testClinic.master_user_id === user?.id || testClinic.owner_id === user?.id;

  const renderContent = () => {
    console.log('🔍 [NewClinicDashboard] renderContent chamado v2.0');
    console.log('🔍 [NewClinicDashboard] activeTab atual:', activeTab);
    console.log('🔍 [NewClinicDashboard] activeTab === "credito"?', activeTab === 'credito');
    console.log('🔍 [NewClinicDashboard] clinic.id:', clinic?.id);
    console.log('🔍 Comparando activeTab com cases:', {
      activeTab,
      isCredit: activeTab === 'credit',
      isCredito: activeTab === 'credito'
    });
    
    switch (activeTab) {
      case 'dashboard':
        return (
          <LoadingState 
            isLoading={false} 
            error={dashboardError}
            loadingText="Carregando dashboard..."
          >
            <div className="space-y-6">
              <ClinicDashboardMetrics clinicId={clinic?.id || testClinic?.id} />
            </div>
          </LoadingState>
        );
      
      case 'agenda':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Dados Clinicorp</h2>
              <p className="text-muted-foreground">
                Sistema integrado de agendamento com Clinicorp
              </p>
            </div>
            {clinic?.clinicorp_enabled ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div>
                    <p className="font-medium text-green-900">Clinicorp Conectado</p>
                    <p className="text-sm text-green-700">Sistema de agenda integrado e funcionando</p>
                  </div>
                  <Button size="sm" variant="outline">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Acessar Agenda
                  </Button>
                </div>
                <ClinicorpDashboard clinicId={clinic?.id || testClinic?.id} />
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Configure a Integração Clinicorp</h3>
                <p className="text-muted-foreground mb-4">
                  Configure suas credenciais do Clinicorp para acessar o sistema de agenda
                </p>
                <Button onClick={() => setActiveTab('config')}>
                  Configurar Agora
                </Button>
              </div>
            )}
          </div>
        );
      
      case 'agendamento':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Gerenciar Agendamento</h2>
              <p className="text-muted-foreground">
                Sistema de agendamento do Doutorizze
              </p>
            </div>
            <div className="text-center py-8">
              <Calendar className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">Agendamento Doutorizze</h3>
              <p className="text-muted-foreground mb-4">
                Gerencie os agendamentos realizados através da plataforma Doutorizze
              </p>
              <Button onClick={() => navigate('/agendamentos')}>
                Acessar Agendamentos
              </Button>
            </div>
          </div>
        );
      
      case 'credit':
      case 'credito':
        console.log('🔥 [NewClinicDashboard] Renderizando aba de crédito!');
        console.log('🔥 [NewClinicDashboard] testClinic.id:', testClinic?.id);
        return (
          <div className="space-y-6">
            <ClinicDashboard />
          </div>
        );
      
      case 'leads':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Gestão de Leads</h2>
              <p className="text-muted-foreground">
                Acompanhe e converta potenciais pacientes em consultas
              </p>
            </div>
            <LeadsManager clinicId={clinic?.id || testClinic?.id} />
          </div>
        );
      
      case 'horarios':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Configuração de Horários</h2>
              <p className="text-muted-foreground">
                Configure os horários de funcionamento e bloqueios da clínica
              </p>
            </div>
            <ConfiguracaoHorariosPage />
          </div>
        );
      
      case 'relatorios':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Relatórios de Agendamentos</h2>
              <p className="text-muted-foreground">
                Visualize relatórios detalhados dos agendamentos
              </p>
            </div>
            <RelatoriosAgendamentosPage />
          </div>
        );

      case 'config':
        return (
          <Card className="w-full">
            <CardHeader className="w-full">
              <CardTitle>Configurações do Clinicorp</CardTitle>
              <p className="text-muted-foreground">
                Configure a integração com o sistema Clinicorp
              </p>
            </CardHeader>
            <CardContent className="w-full">
              <ClinicorpCredentialsForm />
            </CardContent>
          </Card>
        );

      case 'professionals':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Gerenciar Profissionais</h2>
              <p className="text-muted-foreground">
                Gerencie a equipe de profissionais da sua clínica
              </p>
            </div>
            <ProfessionalsManager clinicId={clinic?.id || testClinic?.id} />
          </div>
        );

      case 'support':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Central de Suporte</h2>
              <p className="text-muted-foreground">
                Gerencie tickets de suporte da sua clínica
              </p>
            </div>
            <ClinicSupportCenter clinicId={clinic?.id || testClinic?.id} />
          </div>
        );

      case 'profile':
        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Perfil da Clínica</h2>
              <p className="text-muted-foreground">
                Gerencie as informações e configurações da sua clínica
              </p>
            </div>
            <ClinicProfileManager />
          </div>
        );
      
      case 'advanced-services':
        if (!isMaster) {
          return (
            <Card className="w-full">
              <CardHeader className="w-full">
                <CardTitle className="w-full flex items-center gap-2 text-red-600">
                  <Crown className="h-5 w-5" />
                  Acesso Restrito
                </CardTitle>
              </CardHeader>
              <CardContent className="w-full">
                <p className="text-muted-foreground">
                  Apenas o usuário Master tem acesso aos Serviços Avançados. 
                  Entre em contato com o administrador da clínica para liberar o acesso.
                </p>
              </CardContent>
            </Card>
          );
        }

        if (subscriptionLoading) {
          return (
            <div className="flex items-center justify-center py-8">
              <LoadingSpinner />
              <span className="ml-2">Verificando assinatura...</span>
            </div>
          );
        }

        if (!hasAdvancedSubscription()) {
          return (
            <div className="space-y-6">
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
                  <Crown className="h-6 w-6 text-yellow-500" />
                  Serviços Avançados
                </h2>
                <p className="text-muted-foreground">
                  Funcionalidades premium disponíveis mediante assinatura
                </p>
              </div>
              
              <Card className="w-full border-2 border-yellow-200 bg-yellow-50">
                <CardHeader className="w-full">
                  <CardTitle className="flex items-center gap-2 text-yellow-800">
                    <AlertCircle className="h-5 w-5" />
                    Assinatura Necessária
                  </CardTitle>
                </CardHeader>
                <CardContent className="w-full">
                  <p className="text-yellow-700 mb-4">
                    Para acessar os serviços avançados, é necessário ter uma assinatura ativa do plano Clínica Avançada.
                  </p>
                  <Button 
                    className="w-full"
                    onClick={() => navigate('/plans?type=clinic_advanced')}
                  >
                    Assinar Plano Avançado
                  </Button>
                </CardContent>
              </Card>
            </div>
          );
        }

        return (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
                <Crown className="h-6 w-6 text-yellow-500" />
                Serviços Avançados
              </h2>
              <p className="text-muted-foreground">
                Funcionalidades premium ativas
              </p>
            </div>
            
            <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="w-full border-2 border-green-200 bg-green-50">
                <CardHeader className="w-full">
                  <CardTitle className="text-green-800">Sistema de Clínicas Pay</CardTitle>
                </CardHeader>
                <CardContent className="w-full">
                  <p className="text-green-700 mb-4">
                    Sistema de pagamentos integrado com funcionalidades avançadas
                  </p>
                  <Button 
                    className="w-full"
                    variant="outline"
                  >
                    Acessar Sistema
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="w-full border-2 border-green-200 bg-green-50">
                <CardHeader className="w-full">
                  <CardTitle className="text-green-800">Marketing Automatizado</CardTitle>
                </CardHeader>
                <CardContent className="w-full">
                  <p className="text-green-700 mb-4">
                    Campanhas automáticas e gestão avançada de relacionamento
                  </p>
                  <Button 
                    className="w-full"
                    variant="outline"
                  >
                    Acessar Campanhas
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  console.log('🎯 [NewClinicDashboard] Pronto para renderizar, activeTab:', activeTab);
  
  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-gray-50">
      {/* Navbar da página home */}
      <Navbar />
      
      {/* Container Principal */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar fixa: oculta em mobile, visível em md+ */}
        <div className="hidden md:block md:w-64 flex-shrink-0">
          <AppSidebar />
        </div>

        {/* Main content alinhado sem margem extra e centralizado */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header */}
          <div className="flex-shrink-0 bg-white border-b">
            <div className="container mx-auto px-4 sm:px-6 py-4">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4">
                <div className="md:hidden">
                  <Button variant="ghost" size="icon" onClick={() => setMobileSidebarOpen(true)}>
                    <Menu className="h-5 w-5" />
                  </Button>
                </div>
                <div className="min-w-0">
                  <h1 className="text-2xl sm:text-3xl font-bold text-foreground sm:truncate">Dashboard da Clínica</h1>
                  <p className="text-muted-foreground text-sm sm:text-base">
                    Bem-vindo, {clinic?.name || testClinic?.name || 'Clínica'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Content area */}
          <div className="flex-1 overflow-y-auto">
            <div className="container mx-auto px-4 sm:px-6 py-6">
              {renderContent()}
              <Footer />
            </div>
          </div>
        </div>
      </div>
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileSidebarOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-80 max-w-[85%] bg-white shadow-xl transform transition-transform duration-300 ease-in-out">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <h2 className="text-lg font-semibold">Menu</h2>
              <Button variant="ghost" size="icon" onClick={() => setMobileSidebarOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <div className="h-[calc(100%-56px)] overflow-y-auto">
              <AppSidebar />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NewClinicDashboard;
