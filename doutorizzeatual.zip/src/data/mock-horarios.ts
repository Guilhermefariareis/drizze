// Dados mock para testar o sistema de horários
// Este arquivo simula dados da tabela horarios_funcionamento

export interface HorarioFuncionamentoMock {
  id: string;
  clinic_id: string;
  dia_semana: number; // 0 = Domingo, 1 = Segunda, ..., 6 = Sábado
  hora_inicio: string;
  hora_fim: string;
  created_at: string;
  updated_at: string;
}

// Clinic ID que aparece nos logs
const CLINIC_ID = '311e1db5-ae3a-4998-9eb4-71e7a8bd7f1b';

export const mockHorariosFuncionamento: HorarioFuncionamentoMock[] = [
  // Segunda-feira (1)
  {
    id: '1a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 1,
    hora_inicio: '08:00',
    hora_fim: '12:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '2a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 1,
    hora_inicio: '14:00',
    hora_fim: '18:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  
  // Terça-feira (2)
  {
    id: '3a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 2,
    hora_inicio: '08:00',
    hora_fim: '12:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '4a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 2,
    hora_inicio: '14:00',
    hora_fim: '18:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  
  // Quarta-feira (3)
  {
    id: '5a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 3,
    hora_inicio: '08:00',
    hora_fim: '12:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '6a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 3,
    hora_inicio: '14:00',
    hora_fim: '18:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  
  // Quinta-feira (4)
  {
    id: '7a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 4,
    hora_inicio: '08:00',
    hora_fim: '12:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '8a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 4,
    hora_inicio: '14:00',
    hora_fim: '18:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  
  // Sexta-feira (5)
  {
    id: '9a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 5,
    hora_inicio: '08:00',
    hora_fim: '12:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '0a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p',
    clinic_id: CLINIC_ID,
    dia_semana: 5,
    hora_inicio: '14:00',
    hora_fim: '17:00',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

// Função para simular consulta ao Supabase
export function getMockHorariosFuncionamento(clinicId?: string) {
  if (clinicId) {
    return mockHorariosFuncionamento.filter(h => h.clinic_id === clinicId);
  }
  return mockHorariosFuncionamento;
}

// Função para obter horários de um dia específico
export function getMockHorariosPorDia(diaSemana: number, clinicId?: string) {
  let horarios = mockHorariosFuncionamento.filter(h => h.dia_semana === diaSemana);
  
  if (clinicId) {
    horarios = horarios.filter(h => h.clinic_id === clinicId);
  }
  
  return horarios;
}